This is just a sample script on how to use JSDoc
