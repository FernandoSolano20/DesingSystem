# JSDoc Example

This is some example code to show you how to use JSDoc for documenting your JavaScript and also using it for type checking.

### Usage

```
npm install
# Generate a docs folder with the documentation website
npm run doc
```
